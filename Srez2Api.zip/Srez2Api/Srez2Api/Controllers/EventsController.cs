﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Srez2Api.DataBaseContext;
using Srez2Api.Models;

namespace Srez2Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EventsController : ControllerBase
    {
        private readonly DBEntities _context;

        public EventsController(DBEntities context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var events = await _context.Events.Include(e => e.Participants).ToListAsync();
            return Ok(events);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var ev = await _context.Events.Include(e => e.Participants)
                                          .FirstOrDefaultAsync(e => e.Id == id);
            if (ev == null)
                return NotFound();

            return Ok(ev);
        }

        [HttpPost]
        [Authorize(Roles = "Instructor")]
        public async Task<IActionResult> CreateEvent([FromBody] Event model)
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);
            model.InstructorId = userId;
            _context.Events.Add(model);
            await _context.SaveChangesAsync();
            return Ok(model);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Instructor")]
        public async Task<IActionResult> UpdateEvent(int id, [FromBody] Event model)
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);
            var ev = await _context.Events.FindAsync(id);

            if (ev == null || ev.InstructorId != userId)
                return Forbid();

            ev.Title = model.Title;
            ev.Description = model.Description;
            ev.Date = model.Date;
            await _context.SaveChangesAsync();
            return Ok(ev);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Instructor")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);
            var ev = await _context.Events.FindAsync(id);

            if (ev == null || ev.InstructorId != userId)
                return Forbid();

            _context.Events.Remove(ev);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpPost("signup/{eventId}")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> SignupToEvent(int eventId)
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);

            if (await _context.EventParticipants.AnyAsync(ep => ep.EventId == eventId && ep.ParticipantId == userId))
                return BadRequest("Already signed up.");

            var signup = new EventParticipant
            {
                EventId = eventId,
                ParticipantId = userId
            };
            _context.EventParticipants.Add(signup);
            await _context.SaveChangesAsync();
            return Ok();
        }

        [HttpGet("my-signups")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> MySignups()
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);
            var events = await _context.EventParticipants
                .Where(ep => ep.ParticipantId == userId)
                .Select(ep => ep.EventId)
                .ToListAsync();

            var myEvents = await _context.Events
                .Where(e => events.Contains(e.Id))
                .ToListAsync();

            return Ok(myEvents);
        }
    }
}
