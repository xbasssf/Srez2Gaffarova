﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Srez2Api.DataBaseContext;
using Srez2Api.Models;

namespace Srez2Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ProfileController : ControllerBase
    {
        private readonly DBEntities _context;

        public ProfileController(DBEntities context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetProfile()
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);
            var participant = await _context.Participants.FindAsync(userId);
            if (participant == null)
                return NotFound();

            return Ok(participant);
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProfile([FromBody] Participant model)
        {
            var userId = int.Parse(User.FindFirst("UserId")?.Value);
            var participant = await _context.Participants.FindAsync(userId);

            if (participant == null)
                return NotFound();

            participant.FullName = model.FullName;
            participant.Email = model.Email;
            participant.Phone = model.Phone;
            participant.Bio = model.Bio;

            await _context.SaveChangesAsync();
            return Ok(participant);
        }
    }
}
