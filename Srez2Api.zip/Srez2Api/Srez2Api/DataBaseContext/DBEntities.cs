﻿using Microsoft.EntityFrameworkCore;
using Srez2Api.Models;
using System.Collections.Generic;

namespace Srez2Api.DataBaseContext
{
    public class DBEntities : DbContext
    {
        public DBEntities(DbContextOptions<DBEntities> options) : base(options) { }

        public DbSet<Event> Events { get; set; }
        public DbSet<Participant> Participants { get; set; }
        public DbSet<EventParticipant> EventParticipants { get; set; }
        public DbSet<Login> Logins { get; set; }
        public DbSet<Role> Roles { get; set; }
    }
}
