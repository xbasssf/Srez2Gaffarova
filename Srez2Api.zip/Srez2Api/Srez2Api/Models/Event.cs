﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Srez2Api.Models
{
    public class Event
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Date { get; set; }
        public int InstructorId { get; set; }

        [ForeignKey("InstructorId")]
        public Login Login { get; set; }
        public List<EventParticipant> Participants { get; set; }
    }
}
