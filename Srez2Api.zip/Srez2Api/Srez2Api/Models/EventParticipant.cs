﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Srez2Api.Models
{
    public class EventParticipant
    {
        public int Id { get; set; }
        public int EventId { get; set; }
        public int ParticipantId { get; set; }

        [ForeignKey("ParticipantId")]
        public Participant Participant { get; set; }

        [ForeignKey("EventId")]
        public Event Event { get; set; }
    }
}
