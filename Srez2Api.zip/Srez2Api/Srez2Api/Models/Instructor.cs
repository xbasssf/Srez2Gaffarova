﻿namespace Srez2Api.Models
{
    public class Instructor
    {
    }
}
