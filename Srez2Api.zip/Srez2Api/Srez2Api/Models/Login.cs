﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Srez2Api.Models
{
    public class Login
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public int ParticipantId { get; set; }
        public int RoleId { get; set; }

        [ForeignKey("RoleId")]
        public Role Role { get; set; }
    }
}
