﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Srez2Api.DataBaseContext;
using Srez2Api.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Srez2Api.Services
{
    public class AuthService
    {
        private readonly DBEntities _context;
        private readonly IConfiguration _config;

        public AuthService(DBEntities context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        public async Task<string> Authenticate(string username, string password)
        {
            var user = await _context.Logins.Include(l => l.Role)
                        .FirstOrDefaultAsync(l => l.Username == username);

            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
                return null;

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Username),
                new Claim(ClaimTypes.Role, user.Role.Name),
                new Claim("UserId", user.ParticipantId.ToString())
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: _config["Jwt:Issuer"],
                audience: _config["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(2),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        public async Task<bool> Register(string username, string password, string fullName, string email, string phone, string bio, string roleName)
        {
            if (await _context.Logins.AnyAsync(l => l.Username == username))
                return false;

            var role = await _context.Roles.FirstOrDefaultAsync(r => r.Name == roleName);
            if (role == null) return false;

            var participant = new Participant
            {
                FullName = fullName,
                Email = email,
                Phone = phone,
                Bio = bio
            };
            _context.Participants.Add(participant);
            await _context.SaveChangesAsync();

            var login = new Login
            {
                Username = username,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                ParticipantId = participant.Id,
                RoleId = role.Id
            };
            _context.Logins.Add(login);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
